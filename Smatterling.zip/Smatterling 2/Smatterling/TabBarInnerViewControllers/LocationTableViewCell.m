//
//  LocationTableViewCell.m
//  Smatterling
//
//  Created by Muhammad Usama on 15/03/2017.
//  Copyright © 2017 AlphaAlgorithms. All rights reserved.
//

#import "LocationTableViewCell.h"

@implementation LocationTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
