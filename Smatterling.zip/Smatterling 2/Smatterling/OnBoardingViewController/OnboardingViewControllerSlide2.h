//
//  OnboardingViewControllerSlide2.h
//  Smatterling
//
//  Created by Muhammad Usama on 06/03/2017.
//  Copyright © 2017 AlphaAlgorithms. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OnboardingViewControllerSlide2 : UIViewController
@property NSUInteger pageIndex;
@end
