//
//  CustomAnnotationView.m
//  Smatterling
//
//  Created by Muhammad Usama on 16/03/2017.
//  Copyright © 2017 AlphaAlgorithms. All rights reserved.
//

#import "CustomAnnotationView.h"

@implementation CustomAnnotationView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
