//
//  CustomAnnotationView.h
//  Smatterling
//
//  Created by Muhammad Usama on 16/03/2017.
//  Copyright © 2017 AlphaAlgorithms. All rights reserved.
//

#import <MapKit/MapKit.h>

@interface CustomAnnotationView : MKAnnotationView

@end
