//
//  AvatarCollectionViewCell.m
//  Smatterling
//
//  Created by Muhammad Usama on 15/03/2017.
//  Copyright © 2017 AlphaAlgorithms. All rights reserved.
//

#import "CreateAvatarCollectionViewCell.h"

@implementation CreateAvatarCollectionViewCell

@end
